package com.gameproject.graphicstest;


import android.app.Activity;
import android.os.Bundle;
 
public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new GameView(this));
    }
}

