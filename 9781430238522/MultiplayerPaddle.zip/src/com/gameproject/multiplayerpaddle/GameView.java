package com.gameproject.multiplayerpaddle;



import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;


import android.bluetooth.*;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;


public class GameView extends SurfaceView implements
		SurfaceHolder.Callback {

	private SpriteObject paddle;
	private SpriteObject paddle_other;
	private SpriteObject[] block;
	private SpriteObject ball;
	
	private GameLogic mGameLogic;
	private ArrayBlockingQueue<InputObject> inputObjectPool;
	private int game_width;
	private int game_height;
	
	private Resources res;
	private int[] x_coords;
	private int[] y_coords;
	private int block_count;
	
	private byte[] latest_input;
	
	private Context context;

	private MediaPlayer mp;
	
	
    // Debugging
    private static final String TAG = "BluetoothChatService";
    private static final boolean D = true;

    // Name for the SDP record when creating server socket
    private static final String NAME = "BluetoothChat";

    // Unique UUID for this application
    private static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");

    // Member fields
    private final BluetoothAdapter mAdapter;
    private final Handler mHandler;
    private AcceptThread mAcceptThread;
    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;
    private int mState;

    // Constants that indicate the current connection state
    public static final int STATE_NONE = 0;       // we're doing nothing
    public static final int STATE_LISTEN = 1;     // now listening for incoming connections
    public static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
    public static final int STATE_CONNECTED = 3;  // now connected to a remote device


    
    
	
	
	public GameView(Context con, Handler hand) {
		super(con);
		Log.e("GameVEIW","game view constructor method");
		context = con;
		getHolder().addCallback(this);
		paddle = new SpriteObject(BitmapFactory.decodeResource(getResources(), R.drawable.paddle), 600, 600);
		paddle_other = new SpriteObject(BitmapFactory.decodeResource(getResources(), R.drawable.paddle), 600, 100);
		ball = new SpriteObject(BitmapFactory.decodeResource(getResources(), R.drawable.ball), 600, 300);
		mGameLogic = new GameLogic(getHolder(), this);
		Log.e("GAMEVIEW","GAMELOGIC INITIALIZED");
		createInputObjectPool();
		
		
		res = getResources();
		block_count = res.getInteger(R.integer.blocknumber);
		x_coords = res.getIntArray(R.array.x);
		y_coords = res.getIntArray(R.array.y);
		block = new SpriteObject[block_count];
		for(int i = 0; i < block_count; i++){
			block[i] = new SpriteObject(BitmapFactory.decodeResource(getResources(), R.drawable.block), x_coords[i], y_coords[i]);
		}
		
		
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mState = STATE_NONE;
        mHandler = hand;
        
		mp = MediaPlayer.create(context, R.raw.bounce);
		
		setFocusable(true);
	}

	private void createInputObjectPool() {
		inputObjectPool = new ArrayBlockingQueue<InputObject>(20);
		for (int i = 0; i < 20; i++) {
			inputObjectPool.add(new InputObject(inputObjectPool));
		}
	}

	

		@Override
		public boolean onTouchEvent(MotionEvent event) {
			try {
				int hist = event.getHistorySize();
				if (hist > 0) {
					for (int i = 0; i < hist; i++) {
						InputObject input = inputObjectPool.take();
						input.useEventHistory(event, i);
						mGameLogic.feedInput(input);
					}
				}
				InputObject input = inputObjectPool.take();
				input.useEvent(event);
				mGameLogic.feedInput(input);
			} catch (InterruptedException e) {
			}
			try {
				Thread.sleep(16);
			} catch (InterruptedException e) {
			}
			return true;
		}
		
		
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		mGameLogic.setGameState(mGameLogic.RUNNING);
		mGameLogic.start();
		ball.setMoveY(-10);
		ball.setMoveX(10);


	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		mp.release();
	}
	
	
	@Override
	public void onDraw(Canvas canvas) {
		canvas.drawColor(Color.WHITE);
		ball.draw(canvas);
		paddle.draw(canvas);
		paddle_other.draw(canvas);
		for(int i = 0; i < block_count; i++){
			block[i].draw(canvas);
		}
		game_width = canvas.getWidth();
		game_height = canvas.getHeight();
	}

	public void update(int adj_mov) {
		
		int ball_bottom = (int)(ball.getY() + ball.getBitmap().getHeight());
		int ball_right = (int)(ball.getX() + ball.getBitmap().getWidth());
		int ball_y = (int) ball.getY();
		int ball_x = (int) ball.getX();
		
		//Bottom Collision
		if(ball_bottom > game_height){
			ball.setMoveY(-ball.getMoveY());
			//player loses
		}
		
		//Top collision
		if(ball_y < 0){
			ball.setMoveY(-ball.getMoveY());
		}
		
		//Right-side collision
		if(ball_right > game_width){
			ball.setMoveX(-ball.getMoveX());
		}
		
		//Left-side collision
		if(ball_x < 0){
			ball.setMoveX(-ball.getMoveX());
		}
		
		
		//paddle collision
		if(paddle.collide(ball)){
			if(ball_bottom > paddle.getY() && ball_bottom < paddle.getY() + 20){
				ball.setMoveY(-ball.getMoveY());
			}
		}
		
		int val=0;
		for (int i=latest_input.length-1, j = 0; i >= 0; i--,j++)
			{
				val += (latest_input[i] & 0xff) << (8*j);
			}
		paddle_other.setX(val);
		//paddle_other collision
		int paddle_other_bottom = paddle_other.getBitmap().getHeight();
		if(paddle_other.collide(ball)){
			if(ball_y < paddle_other_bottom && ball_y < paddle_other_bottom + 20){
				ball.setMoveY(-ball.getMoveY());
			}
		}
		
		//check for brick collisions
		for(int i = 0; i < block_count; i++){
			if(ball.collide(block[i])){
				block[i].setstate(block[i].DEAD);
				mp.start();
				int block_bottom = (int)(block[i].getY() + block[i].getBitmap().getHeight());
				int block_right =(int)(block[i].getX() + block[i].getBitmap().getWidth());

				
				//hits bottom of block
				if(ball_y > block_bottom - 10){
					ball.setMoveY(ball.getMoveY());
				}
				//hits top of block
				else if(ball_bottom < block[i].getY() + 10){
					ball.setMoveY(-ball.getMoveY());
				}
				//hits from right
				else if(ball_x > block_right - 10){
					ball.setMoveX(ball.getMoveX());
				}
				//hits from left
				else if(ball_right < block[i].getX() + 10){
					ball.setMoveX(-ball.getMoveX());
				}

			}
		}
	
		byte[] paddle_output;
	    ByteBuffer bb = ByteBuffer.allocate(4); 
	    bb.putInt((int)paddle.getX()); 
	    paddle_output = bb.array();
		write(paddle_output);

		//perform specific updates
		for(int i = 0; i < block_count; i++){
			block[i].update(adj_mov);
		}		
		paddle.update(adj_mov);
		paddle_other.update(adj_mov);
		ball.update(adj_mov);
		

	}
	
	
	
	public void processMotionEvent(InputObject input){
		paddle.setX(input.x);
		paddle.setY(input.y);

	}
	
	public void processKeyEvent(InputObject input){

	}

	public void processOrientationEvent(float orientation[]){
		
		float roll = orientation[2];
		if (roll < -40) {
			//sprite.setMoveX(2);
		} else if (roll > 40) {
			//sprite.setMoveX(-2);
		}
		
	}


	







	    /**
	     * Set the current state of the chat connection
	     * @param state  An integer defining the current connection state
	     */
	    private synchronized void setState(int state) {
	        if (D) Log.d(TAG, "setState() " + mState + " -> " + state);
	        mState = state;

	        // Give the new state to the Handler so the UI Activity can update
	        mHandler.obtainMessage(BluetoothChat.MESSAGE_STATE_CHANGE, state, -1).sendToTarget();
	    }

	    /**
	     * Return the current connection state. */
	    public synchronized int getState() {
	        return mState;
	    }

	    /**
	     * Start the chat service. Specifically start AcceptThread to begin a
	     * session in listening (server) mode. Called by the Activity onResume() */
	    public synchronized void start() {
	        if (D) Log.d(TAG, "start");

	        // Cancel any thread attempting to make a connection
	        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

	        // Cancel any thread currently running a connection
	        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

	        // Start the thread to listen on a BluetoothServerSocket
	        if (mAcceptThread == null) {
	            mAcceptThread = new AcceptThread();
	            mAcceptThread.start();
	        }
	        setState(STATE_LISTEN);
	    }

	    /**
	     * Start the ConnectThread to initiate a connection to a remote device.
	     * @param device  The BluetoothDevice to connect
	     */
	    public synchronized void connect(BluetoothDevice device) {
	        if (D) Log.d(TAG, "connect to: " + device);

	        // Cancel any thread attempting to make a connection
	        if (mState == STATE_CONNECTING) {
	            if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
	        }

	        // Cancel any thread currently running a connection
	        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

	        // Start the thread to connect with the given device
	        mConnectThread = new ConnectThread(device);
	        mConnectThread.start();
	        setState(STATE_CONNECTING);
	    }

	    /**
	     * Start the ConnectedThread to begin managing a Bluetooth connection
	     * @param socket  The BluetoothSocket on which the connection was made
	     * @param device  The BluetoothDevice that has been connected
	     */
	    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
	        if (D) Log.d(TAG, "connected");

	        // Cancel the thread that completed the connection
	        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

	        // Cancel any thread currently running a connection
	        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}

	        // Cancel the accept thread because we only want to connect to one device
	        if (mAcceptThread != null) {mAcceptThread.cancel(); mAcceptThread = null;}

	        // Start the thread to manage the connection and perform transmissions
	        mConnectedThread = new ConnectedThread(socket);
	        mConnectedThread.start();

	        // Send the name of the connected device back to the UI Activity
	        Message msg = mHandler.obtainMessage(BluetoothChat.MESSAGE_DEVICE_NAME);
	        Bundle bundle = new Bundle();
	        bundle.putString(BluetoothChat.DEVICE_NAME, device.getName());
	        msg.setData(bundle);
	        mHandler.sendMessage(msg);

	        setState(STATE_CONNECTED);
	    }

	    /**
	     * Stop all threads
	     */
	    public synchronized void stop() {
	        if (D) Log.d(TAG, "stop");
	        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
	        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}
	        if (mAcceptThread != null) {mAcceptThread.cancel(); mAcceptThread = null;}
	        setState(STATE_NONE);
	    }

	    /**
	     * Write to the ConnectedThread in an unsynchronized manner
	     * @param out The bytes to write
	     * @see ConnectedThread#write(byte[])
	     */
	    public void write(byte[] out) {
	        // Create temporary object
	        ConnectedThread r;
	        // Synchronize a copy of the ConnectedThread
	        synchronized (this) {
	            if (mState != STATE_CONNECTED) return;
	            r = mConnectedThread;
	        }
	        // Perform the write unsynchronized
	        r.write(out);
	    }

	    /**
	     * Indicate that the connection attempt failed and notify the UI Activity.
	     */
	    private void connectionFailed() {
	        setState(STATE_LISTEN);

	        // Send a failure message back to the Activity
	        Message msg = mHandler.obtainMessage(BluetoothChat.MESSAGE_TOAST);
	        Bundle bundle = new Bundle();
	        bundle.putString(BluetoothChat.TOAST, "Unable to connect device");
	        msg.setData(bundle);
	        mHandler.sendMessage(msg);
	    }

	    /**
	     * Indicate that the connection was lost and notify the UI Activity.
	     */
	    private void connectionLost() {
	        setState(STATE_LISTEN);

	        // Send a failure message back to the Activity
	        Message msg = mHandler.obtainMessage(BluetoothChat.MESSAGE_TOAST);
	        Bundle bundle = new Bundle();
	        bundle.putString(BluetoothChat.TOAST, "Device connection was lost");
	        msg.setData(bundle);
	        mHandler.sendMessage(msg);
	    }

	    /**
	     * This thread runs while listening for incoming connections. It behaves
	     * like a server-side client. It runs until a connection is accepted
	     * (or until cancelled).
	     */
	    private class AcceptThread extends Thread {
	        // The local server socket
	        private final BluetoothServerSocket mmServerSocket;

	        public AcceptThread() {
	            BluetoothServerSocket tmp = null;

	            // Create a new listening server socket
	            try {
	                tmp = mAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
	            } catch (IOException e) {
	                Log.e(TAG, "listen() failed", e);
	            }
	            mmServerSocket = tmp;
	        }

	        public void run() {
	            if (D) Log.d(TAG, "BEGIN mAcceptThread" + this);
	            setName("AcceptThread");
	            BluetoothSocket socket = null;

	            // Listen to the server socket if we're not connected
	            while (mState != STATE_CONNECTED) {
	                try {
	                    // This is a blocking call and will only return on a
	                    // successful connection or an exception
	                    socket = mmServerSocket.accept();
	                } catch (IOException e) {
	                    Log.e(TAG, "accept() failed", e);
	                    break;
	                }

	                // If a connection was accepted
	                if (socket != null) {
	                    synchronized (GameView.this) {
	                        switch (mState) {
	                        case STATE_LISTEN:
	                        case STATE_CONNECTING:
	                            // Situation normal. Start the connected thread.
	                            connected(socket, socket.getRemoteDevice());
	                            break;
	                        case STATE_NONE:
	                        case STATE_CONNECTED:
	                            // Either not ready or already connected. Terminate new socket.
	                            try {
	                                socket.close();
	                            } catch (IOException e) {
	                                Log.e(TAG, "Could not close unwanted socket", e);
	                            }
	                            break;
	                        }
	                    }
	                }
	            }
	            if (D) Log.i(TAG, "END mAcceptThread");
	        }

	        public void cancel() {
	            if (D) Log.d(TAG, "cancel " + this);
	            try {
	                mmServerSocket.close();
	            } catch (IOException e) {
	                Log.e(TAG, "close() of server failed", e);
	            }
	        }
	    }


	    /**
	     * This thread runs while attempting to make an outgoing connection
	     * with a device. It runs straight through; the connection either
	     * succeeds or fails.
	     */
	    private class ConnectThread extends Thread {
	        private final BluetoothSocket mmSocket;
	        private final BluetoothDevice mmDevice;

	        public ConnectThread(BluetoothDevice device) {
	            mmDevice = device;
	            BluetoothSocket tmp = null;

	            // Get a BluetoothSocket for a connection with the
	            // given BluetoothDevice
	            try {
	                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
	            } catch (IOException e) {
	                Log.e(TAG, "create() failed", e);
	            }
	            mmSocket = tmp;
	        }

	        public void run() {
	            Log.i(TAG, "BEGIN mConnectThread");
	            setName("ConnectThread");

	            // Always cancel discovery because it will slow down a connection
	            mAdapter.cancelDiscovery();

	            // Make a connection to the BluetoothSocket
	            try {
	                // This is a blocking call and will only return on a
	                // successful connection or an exception
	                mmSocket.connect();
	            } catch (IOException e) {
	                connectionFailed();
	                // Close the socket
	                try {
	                    mmSocket.close();
	                } catch (IOException e2) {
	                    Log.e(TAG, "unable to close() socket during connection failure", e2);
	                }
	                // Start the service over to restart listening mode
	                GameView.this.start();
	                return;
	            }

	            // Reset the ConnectThread because we're done
	            synchronized (GameView.this) {
	                mConnectThread = null;
	            }

	            // Start the connected thread
	            connected(mmSocket, mmDevice);
	        }

	        public void cancel() {
	            try {
	                mmSocket.close();
	            } catch (IOException e) {
	                Log.e(TAG, "close() of connect socket failed", e);
	            }
	        }
	    }

	    /**
	     * This thread runs during a connection with a remote device.
	     * It handles all incoming and outgoing transmissions.
	     */
	    private class ConnectedThread extends Thread {
	        private final BluetoothSocket mmSocket;
	        private final InputStream mmInStream;
	        private final OutputStream mmOutStream;

	        public ConnectedThread(BluetoothSocket socket) {
	            Log.d(TAG, "create ConnectedThread");
	            mmSocket = socket;
	            InputStream tmpIn = null;
	            OutputStream tmpOut = null;

	            // Get the BluetoothSocket input and output streams
	            try {
	                tmpIn = socket.getInputStream();
	                tmpOut = socket.getOutputStream();
	            } catch (IOException e) {
	                Log.e(TAG, "temp sockets not created", e);
	            }

	            mmInStream = tmpIn;
	            mmOutStream = tmpOut;
	        }

	        public void run() {
	            Log.i(TAG, "BEGIN mConnectedThread");
	            //byte[] buffer = new byte[1024];
	            int bytes;

	            // Keep listening to the InputStream while connected
	            while (true) {
	                try {
	                    // Read from the InputStream
	                    bytes = mmInStream.read(latest_input);

	                    // Send the obtained bytes to the UI Activity
	                    mHandler.obtainMessage(BluetoothChat.MESSAGE_READ, bytes, -1, latest_input)
	                            .sendToTarget();
	                } catch (IOException e) {
	                    Log.e(TAG, "disconnected", e);
	                    connectionLost();
	                    break;
	                }
	            }
	        }

	        /**
	         * Write to the connected OutStream.
	         * @param buffer  The bytes to write
	         */
	        public void write(byte[] buffer) {
	            try {
	                mmOutStream.write(buffer);

	                // Share the sent message back to the UI Activity
	                mHandler.obtainMessage(BluetoothChat.MESSAGE_WRITE, -1, -1, buffer)
	                        .sendToTarget();
	            } catch (IOException e) {
	                Log.e(TAG, "Exception during write", e);
	            }
	        }

	        public void cancel() {
	            try {
	                mmSocket.close();
	            } catch (IOException e) {
	                Log.e(TAG, "close() of connect socket failed", e);
	            }
	        }
	    }
	

	

	
}
